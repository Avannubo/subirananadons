'use client';
import { FiFilter, FiSearch, FiUpload, FiDownload, FiEdit, FiAlertCircle } from 'react-icons/fi';
import { useState, useEffect, useCallback } from 'react';
import { toast } from 'react-hot-toast';
import ConfirmModal from '@/components/shared/ConfirmModal';
import Pagination from '@/components/admin/shared/Pagination';
export default function StockManagement() {
    const [products, setProducts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');
    const [showLowStock, setShowLowStock] = useState(false);
    const [editingId, setEditingId] = useState(null);
    const [quantities, setQuantities] = useState({});
    const [pagination, setPagination] = useState({
        currentPage: 1,
        totalPages: 1,
        totalItems: 0,
        limit: 5
    });
    const [confirmModal, setConfirmModal] = useState({
        isOpen: false,
        title: '',
        message: '',
        onConfirm: () => { }
    });
    // Fetch products from the API
    const fetchProducts = useCallback(async (page = 1, limit = pagination.limit) => {
        try {
            setLoading(true);
            const queryParams = new URLSearchParams();
            queryParams.append('page', page);
            queryParams.append('limit', limit);
            // Add stock filter if enabled
            if (showLowStock) {
                queryParams.append('lowStock', 'true');
            }
            // Add search term if present
            if (searchTerm) {
                queryParams.append('search', searchTerm);
            }
            const response = await fetch(`/api/products?${queryParams.toString()}`);
            if (!response.ok) {
                throw new Error('Failed to fetch products');
            }
            const data = await response.json();
            setProducts(data.products || []);
            setPagination({
                currentPage: data.pagination?.currentPage || page,
                totalPages: data.pagination?.totalPages || 1,
                totalItems: data.pagination?.totalItems || 0,
                limit: limit
            });
        } catch (error) {
            console.error('Error fetching products:', error);
            toast.error('Error en carregar els productes');
            setProducts([]);
        } finally {
            setLoading(false);
        }
    }, [searchTerm, showLowStock, pagination.limit]);
    // Initial load and refresh when filters change
    useEffect(() => {
        fetchProducts(1);
    }, [fetchProducts, searchTerm, showLowStock]);
    // Handle page change
    const handlePageChange = (page) => {
        fetchProducts(page);
    };
    // Add handler for items per page change
    const handleLimitChange = (limit) => {
        setPagination(prev => ({ ...prev, limit }));
        fetchProducts(1, limit);
    };
    // Handle quantity change in edit mode
    const handleQuantityChange = (id, field, value) => {
        setQuantities(prev => ({
            ...prev,
            [id]: {
                ...prev[id],
                [field]: parseInt(value) || 0
            }
        }));
    };
    // Save stock changes
    const saveStockChanges = async (productId) => {
        if (!quantities[productId]) {
            setEditingId(null);
            return;
        }
        try {
            // Find the current product in our products array
            const product = products.find(p => p._id === productId);
            if (!product) {
                toast.error('Producte no trobat');
                setEditingId(null);
                return;
            }
            // Show confirmation modal
            setConfirmModal({
                isOpen: true,
                title: 'Confirmar canvi d\'estoc',
                message: `Estàs segur que vols actualitzar l\'estoc disponible del producte? Aquesta acció no es pot desfer.`,
                onConfirm: async () => {
                    try {
                        const toastId = toast.loading('Actualitzant estoc...');
                        // Get the new values from quantities
                        const newAvailable = quantities[productId].available;
                        const newMinStock = quantities[productId].minStock ?? product.stock?.minStock ?? 5;
                        const response = await fetch(`/api/products/${productId}/stock`, {
                            method: 'PUT',
                            headers: {
                                'Content-Type': 'application/json',
                            },
                            body: JSON.stringify({
                                stock: {
                                    available: newAvailable,
                                    minStock: newMinStock
                                }
                            }),
                        });
                        if (!response.ok) {
                            const error = await response.json();
                            throw new Error(error.message || 'Error en actualitzar l\'estoc');
                        }
                        // Update product in the local state
                        const updatedProduct = await response.json();
                        setProducts(prevProducts =>
                            prevProducts.map(p =>
                                p._id === productId ? updatedProduct : p
                            )
                        );
                        // Clear the quantities for this product
                        setQuantities(prev => {
                            const newQuantities = { ...prev };
                            delete newQuantities[productId];
                            return newQuantities;
                        }); 
                        toast.success('Estoc actualitzat correctament', { id: toastId });
                    } catch (error) {
                        console.error('Error updating stock:', error);
                        toast.error(error.message || 'Error en actualitzar l\'estoc');
                    } finally {
                        setEditingId(null);
                        setConfirmModal(prev => ({ ...prev, isOpen: false }));
                    }
                }
            });
        } catch (error) {
            console.error('Error preparing stock update:', error);
            toast.error('Error en preparar l\'actualització d\'estoc');
            setEditingId(null);
        }
    };
    // Get NextIntl locale from Next.js
    let locale = 'ca';
    if (typeof window !== 'undefined') {
        locale = (window.__NEXT_INTL_LOCALE || window.navigator.language || 'ca').split('-')[0];
        if (locale !== 'ca' && locale !== 'es') locale = 'ca';
    }
    // Get translated product name
    const getTranslatedProductName = (product) => {
        if (!product) return 'N/D';
        if (product.name && typeof product.name === 'object') {
            return product.name[locale] || product.name.ca || product.name.es || 'N/D';
        }
        return product.name || 'N/D';
    };
    // Get translated category name
    const getTranslatedCategoryName = (product) => {
        if (!product || !product.category) return 'N/D';
        // If category is an object with translations
        if (typeof product.category === 'object' && product.category !== null) {
            if (product.category && typeof product.category === 'object') {
                return product.category[locale] || product.category.ca || product.category.es || 'N/D';
            }
            // If category itself is a string
            if (typeof product.category === 'string') {
                return product.category;
            }
        }
        // If category is a string
        if (typeof product.category === 'string') {
            return product.category;
        }
        return 'N/D';
    };
    // Get current available stock
    const getAvailableStock = (product) => {
        if (editingId === product._id) {
            return quantities[product._id]?.available ?? (product.stock?.available ?? 0);
        }
        return product.stock?.available ?? 0;
    };
    // Determine if product is low on stock
    const isLowStock = (product) => {
        const available = getAvailableStock(product);
        return available < (product.stock?.minStock ?? 5);
    };
    // Handle export of stock data
    const handleExportStock = () => {
        // Create CSV content
        const headers = ['ID', 'Referència', 'Nom', 'Disponible', 'Estoc mínim', 'Estat'];
        const csvContent = [
            headers.join(','),
            ...products.map(product => [
                product._id,
                product.reference,
                `"${product.name.replace(/"/g, '""')}"`,
                getAvailableStock(product),
                product.stock?.minStock ?? 5,
                product.status
            ].join(','))
        ].join('\n');
        // Create download link
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.setAttribute('href', url);
        link.setAttribute('download', `stock-report-${new Date().toISOString().split('T')[0]}.csv`);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };
    return (
        <div className="bg-white rounded-lg shadow">
            {/* Header with title and actions */}
            <div className="p-4 border-b border-gray-200 flex justify-between items-center">
                <h2 className="text-lg font-semibold">Gestió d'estoc</h2>
            </div>
            {/* Search and filters */}
            <div className="p-4 border-b border-gray-200">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                    <div className="relative flex-grow">
                        <FiSearch className="absolute left-3 top-3 text-gray-400" />
                        <input
                            type="text"
                            placeholder="Cerca de productes (per nom, referència, categoria)"
                            className="pl-10 pr-4 py-2 border border-gray-300 rounded w-full"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                    </div>
                    <div className="flex items-center space-x-4">
                        <label className="flex items-center space-x-2">
                            <input
                                type="checkbox"
                                checked={showLowStock}
                                onChange={() => setShowLowStock(!showLowStock)}
                                className="rounded border-gray-300 text-[#36A9E1] focus:ring-[#36A9E1]"
                            />
                            <span>Mostrar només productes amb estoc baix</span>
                        </label>
                    </div>
                </div>
            </div>
            {/* Stock table */}
            <div className="overflow-x-auto">
                {loading ? (
                    <div className="flex justify-center items-center py-8">
                        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-[#36A9E1]"></div>
                        <span className="ml-2">Carregant productes...</span>
                    </div>
                ) : products.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">
                        No s'han trobat productes que coincideixin amb els criteris de cerca
                    </div>
                ) : (
                    <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                            <tr>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Producte</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Referència</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Categoria</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Estat</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Estoc disponible</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Estoc mínim</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Accions</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                            {products.map((product) => (
                                <tr key={product._id} className={isLowStock(product) ? 'bg-yellow-50' : ''}>
                                    <td className="px-6 py-4 whitespace-nowrap">
                                        <div className="text-sm font-medium text-gray-900">{getTranslatedProductName(product)}</div>
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        {product.reference}
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        {getTranslatedCategoryName(product)}
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap">
                                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${product.status === 'active'
                                            ? 'bg-green-100 text-green-800'
                                            : product.status === 'inactive'
                                                ? 'bg-gray-100 text-gray-800'
                                                : 'bg-red-100 text-red-800'
                                            }`}>
                                            {product.status === 'active'
                                                ? 'Actiu'
                                                : product.status === 'inactive'
                                                    ? 'Inactiu'
                                                    : 'Descatalogat'}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                        <div className="flex items-center">
                                            {editingId === product._id ? (
                                                <input
                                                    type="number"
                                                    min="0"
                                                    className="w-16 border rounded p-1"
                                                    value={quantities[product._id]?.available ?? getAvailableStock(product)}
                                                    onChange={(e) => handleQuantityChange(product._id, 'available', e.target.value)}
                                                />
                                            ) : (
                                                <>
                                                    {getAvailableStock(product)}
                                                    {isLowStock(product) && (
                                                        <FiAlertCircle className="ml-1 text-amber-500" title="Estoc baix" />
                                                    )}
                                                </>
                                            )}
                                        </div>
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        {editingId === product._id ? (
                                            <input
                                                type="number"
                                                min="0"
                                                className="w-16 border rounded p-1"
                                                value={quantities[product._id]?.minStock ?? (product.stock?.minStock ?? 5)}
                                                onChange={(e) => handleQuantityChange(product._id, 'minStock', e.target.value)}
                                            />
                                        ) : (
                                            product.stock?.minStock ?? 5
                                        )}
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                        {editingId === product._id ? (
                                            <div className="flex space-x-2">
                                                <button
                                                    onClick={() => saveStockChanges(product._id)}
                                                    className="text-[#36A9E1] hover:text-[#00B0C870] cursor-pointer"
                                                >
                                                    Desa
                                                </button>
                                                <button
                                                    onClick={() => setEditingId(null)}
                                                    className="text-gray-500 hover:text-gray-700 cursor-pointer"
                                                >
                                                    Cancel·la
                                                </button>
                                            </div>
                                        ) : (
                                            <button
                                                onClick={() => setEditingId(product._id)}
                                                className="flex items-center text-gray-600 hover:text-gray-900 cursor-pointer"
                                            >
                                                <FiEdit className="mr-1" />
                                                Edita
                                            </button>
                                        )}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                )}
            </div>
            {/* Pagination */}
            {products.length > 0 && (
                <div className="px-4 py-3 border-t border-gray-200">
                    <Pagination
                        currentPage={pagination.currentPage}
                        totalPages={pagination.totalPages}
                        totalItems={pagination.totalItems}
                        itemsPerPage={pagination.limit}
                        onPageChange={handlePageChange}
                        onItemsPerPageChange={handleLimitChange}
                        showingText="Mostrant {} de {} productes"
                    />
                </div>
            )}
            {/* Confirmation Modal */}
            <ConfirmModal
                isOpen={confirmModal.isOpen}
                onClose={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
                onConfirm={confirmModal.onConfirm}
                title={confirmModal.title}
                message={confirmModal.message}
                confirmText="Confirma"
                cancelText="Cancel·la"
            />
        </div>
    );
}