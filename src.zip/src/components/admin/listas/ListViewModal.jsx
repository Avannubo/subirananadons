'use client';
import { FiX, FiChevronLeft, FiChevronRight } from 'react-icons/fi';
import Image from 'next/image';
import { useUser } from '@/contexts/UserContext';
import { useState, useCallback, useEffect } from 'react';
// Helper to get product name in correct locale with fallback
function getProductName(product, locale = 'es') {
    //console.log('getProductName called with:', product, locale);
    if (!product) return 'ND';
    if (locale === 'ca' && product.name.ca && typeof product.name.ca === 'string' && product.name.ca.trim()) return product.name.ca;
    if (locale === 'es' && product.name.es && typeof product.name.es === 'string' && product.name.es.trim()) return product.name.es;
    if (product.name.es && typeof product.name.es === 'string' && product.name.es.trim()) return product.name.es;
    if (product.name.ca && typeof product.name.ca === 'string' && product.name.ca.trim()) return product.name.ca;
    if (product.name && typeof product.name === 'string' && product.name.trim()) return product.name;
    return 'ND';
}
// Translation object for Catalan and Spanish
const translations = {
    ca: {
        details: 'Detalls de la Llista',
        info: 'Informació de la Llista',
        reference: 'Referència:',
        babyName: 'Nom del Nadó:',
        visibility: 'Visibilitat:',
        public: 'Pública',
        private: 'Privada',
        description: 'Descripció:',
        date: 'Data',
        total: 'Total',
        dueDate: 'Data Prevista',
        status: 'Estat',
        active: 'Activa',
        completed: 'Completada',
        inactive: 'Inactiva',
        activeDesc: 'Aquesta llista està disponible per rebre regals',
        completedDesc: 'Tots els productes han estat rebuts',
        inactiveDesc: 'Aquesta llista ha estat inactiva',
        pendingProducts: 'Productes Pendents',
        boughtProducts: 'Productes Comprats',
        reservedProducts: 'Productes Reservats',
        progress: 'Progrés',
        totalProducts: 'Total Productes',
        receivedProducts: 'Productes Rebuts',
        noPending: 'No hi ha productes pendents.',
        noBought: 'No hi ha productes comprats.',
        noReserved: 'No hi ha productes reservats.',
        reservedTag: 'Reservat',
        statePending: 'Pendent',
        stateReserved: 'Reservat',
        stateBought: 'Comprat',
        stateUnknown: 'Desconegut',
        errorProductData: 'Error: Dades del producte no disponibles',
        productId: 'ID de l’article:',
        cancel: 'Cancel·lar',
        save: 'Tancar',
        buyerData: 'Dades del comprador',
        name: 'Nom *',
        email: 'Email',
        phone: 'Telèfon',
        message: 'Missatge',
        guardar: 'Desar',
        cancelarCompra: 'Cancelar Compra',
        purchased: 'Productes Rebuts',
        productos: 'productes',
        progresoTotal: 'Progrés total',
        guardarBtn: 'Desar',
        cerrar: 'Tancar',
        reservar: 'Reservar',
        comprar: 'Comprar',
        cancelarReserva: 'Cancel·lar',
        guardarCambios: 'Desar',
    },
    es: {
        details: 'Detalles de la Lista',
        info: 'Información de la Lista',
        reference: 'Referencia:',
        babyName: 'Nombre del Bebé:',
        visibility: 'Visibilidad:',
        public: 'Pública',
        private: 'Privada',
        description: 'Descripción:',
        date: 'Fecha',
        total: 'Total',
        dueDate: 'Fecha Prevista',
        status: 'Estado',
        active: 'Activa',
        completed: 'Completada',
        inactive: 'InActiva',
        activeDesc: 'Esta lista está disponible para recibir regalos',
        completedDesc: 'Todos los productos fueron recibidos',
        inactiveDesc: 'Esta lista ha sido InActiva',
        pendingProducts: 'Productos Pendientes',
        boughtProducts: 'Productos Comprados',
        reservedProducts: 'Productos Reservados',
        progress: 'Progreso',
        totalProducts: 'Total Productos',
        receivedProducts: 'Productos Recibidos',
        noPending: 'No hay productos pendientes.',
        noBought: 'No hay productos comprados.',
        noReserved: 'No hay productos reservados.',
        reservedTag: 'Reservado',
        statePending: 'Pendiente',
        stateReserved: 'Reservado',
        stateBought: 'Comprado',
        stateUnknown: 'Desconocido',
        errorProductData: 'Error: Datos del producto no disponibles',
        productId: 'ID del artículo:',
        cancel: 'Cancelar',
        save: 'Guardar',
        buyerData: 'Datos del comprador',
        name: 'Nombre *',
        email: 'Email',
        phone: 'Teléfono',
        message: 'Mensaje',
        guardar: 'Guardar',
        cancelarCompra: 'Cancelar Compra',
        purchased: 'Productos Recibidos',
        productos: 'productos',
        progresoTotal: 'Progreso total',
        guardarBtn: 'Guardar',
        cerrar: 'Cerrar',
        reservar: 'Reservar',
        comprar: 'Comprar',
        cancelarReserva: 'Cancelar',
        guardarCambios: 'Guardar',
    }
};
function getLocale() {
    if (typeof window !== 'undefined') {
        const lang = window.navigator.language || 'es';
        return lang.startsWith('ca') ? 'ca' : 'es';
    }
    return 'es';
}
import { updateBirthListItems, fetchBirthListItems, updateBirthListItemState, updateBirthList } from '@/services/BirthListService';
import { toast } from 'react-hot-toast';
export default function ListViewModal({
    showModal,
    setShowModal,
    selectedList,
    listItems,
    itemsLoading,
    openEditModal,
    openStatusModal,
    onStatusChange
}) {
    // console.log(selectedList);
    const [pendingSearch, setPendingSearch] = useState('');
    const [boughtSearch, setBoughtSearch] = useState('');
    const [reservedSearch, setReservedSearch] = useState('');
    const locale = getLocale();
    const t = translations[locale];
    const [loading, setLoading] = useState(false);
    const [items, setItems] = useState([]);
    const { user, loading: userLoading } = useUser();
    const [showDataModal, setShowDataModal] = useState(false);
    const [currentItem, setCurrentItem] = useState(null);
    const [direction, setDirection] = useState(null);
    const [showCancelConfirm, setShowCancelConfirm] = useState(false);
    const [cancelItem, setCancelItem] = useState(null);
    const [userData, setUserData] = useState({
        name: '',
        email: '',
        phone: '',
        message: ''
    });
    // Reset userData when modal closes or changes item
    useEffect(() => {
        if (!showModal || !currentItem) {
            setUserData({
                name: '',
                email: '',
                phone: '',
                message: ''
            });
        } else if (currentItem.userData) {
            // If editing an item that already has userData, populate the form
            setUserData({
                name: currentItem.userData.name || '',
                email: currentItem.userData.email || '',
                phone: currentItem.userData.phone || '',
                message: currentItem.userData.message || ''
            });
        }
    }, [showModal, currentItem]);
    const handleUserDataChange = (e) => {
        const { name, value } = e.target;
        setUserData(prev => ({
            ...prev,
            [name]: value
        }));
    };
    const calculatePurchasedProducts = useCallback(() => {
        return items.filter(item => item.state === 2).length;
    }, [items]);
    const calculateProgress = useCallback(() => {
        if (items.length === 0) return 0;
        return Math.round((calculatePurchasedProducts() / items.length) * 100);
    }, [items.length, calculatePurchasedProducts]);
    useEffect(() => {
        if (!showModal) {
            setItems([]);
        }
        else if (Array.isArray(listItems)) {
            setItems(listItems);
        }
    }, [listItems, showModal]);
    const filterByProductName = useCallback((items, searchTerm) => {
        if (!searchTerm) return items;
        return items.filter(item => {
            const productName = getProductName(item.product, locale).toLowerCase();
            return productName.includes(searchTerm.toLowerCase());
        });
    }, [locale]);
    const getPendingItems = useCallback(() => {
        const pendingItems = items.filter(item => item.state === 0);
        return filterByProductName(pendingItems, pendingSearch);
    }, [items, pendingSearch, filterByProductName]);
    const getReservedItems = useCallback(() => {
        const reservedItems = items.filter(item => item.state === 1);
        return filterByProductName(reservedItems, reservedSearch);
    }, [items, reservedSearch, filterByProductName]);
    const getBoughtItems = useCallback(() => {
        const boughtItems = items.filter(item => item.state === 2);
        return filterByProductName(boughtItems, boughtSearch);
    }, [items, boughtSearch, filterByProductName]);
    const confirmStateChange = async () => {
        if (!currentItem) return;
        const listId = selectedList.rawData?._id || selectedList._id;

        if (!listId) {
            toast.error('Error: ID de lista no encontrado');
            return;
        }
        try {
            // Get the new state based on direction
            let newState;
            switch (direction) {
                case 'left':
                    newState = 0; // Always move to pending state when canceling
                    break;
                case 'reserve':
                    newState = 1;
                    break;
                case 'buy':
                    newState = 2;
                    break;
                default:
                    return;
            }
            // Validate state change
            if (newState === currentItem.state) {
                return toast.error('El producto ya está en este estado');
            }
            // Check required fields for reserve/buy actions
            // if ((direction === 'reserve' || direction === 'buy') && (!userData.name)) {
            //     toast.error('Nom és obligatori');
            //     return;
            // }
            setLoading(true);
            // When canceling (moving left), we want to clear the userData
            const dataToSend = direction === 'left' ? null : userData;
            // Update the item's state
            const result = await updateBirthListItemState(listId, currentItem._id, newState, dataToSend);
            if (result.success) {
                // Update the item in the local state
                const updatedItems = items.map(item =>
                    item._id === currentItem._id ? result.data : item
                );
                setItems(updatedItems);
                toast.success('Estado del producto actualizado correctamente');
                setShowDataModal(false);
                setUserData({
                    name: '',
                    email: '',
                    phone: '',
                    message: ''
                });
                // Send email notification for reserved or purchased product via API route
                try {
                    if (newState === 1) {
                        await fetch('/api/send-gift-notification', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify({
                                selectedList,
                                action: 'reserve',
                                item: result.data
                            })
                        });
                    } else if (newState === 2) {
                        await fetch('/api/send-gift-notification', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify({
                                selectedList,
                                action: 'buy',
                                item: result.data
                            })
                        });
                    }
                } catch (emailError) {
                    console.error('Error sending notification email:', emailError);
                }
            }
        } catch (error) {
            console.error('Error updating item state:', error);
            toast.error(error.message || 'Error al actualizar el estado del producto');
        } finally {
            setLoading(false);
        }
    };
    const moveItem = async (item, dir) => {
        if (dir === 'left') {
            setCancelItem(item);
            setShowCancelConfirm(true);
        } else {
            setCurrentItem(item);
            setDirection(dir);
            setShowDataModal(true);
            if (item.userData) {
                setUserData({
                    name: item.userData.name || '',
                    email: item.userData.email || '',
                    phone: item.userData.phone || '',
                    message: item.userData.message || ''
                });
            }
        }
    };
    const renderStateLabel = (state) => {
        switch (state) {
            case 0: return t.statePending;
            case 1: return t.stateReserved;
            case 2: return t.stateBought;
            default: return t.stateUnknown;
        }
    };
    const handleSaveList = async () => {
        try {
            const listId = selectedList.rawData?._id || selectedList._id;
            if (!listId) {
                toast.error('Error: ID de lista no encontrado');
                return;
            }
            setLoading(true);
            // Check if all items are in state 2 (bought)
            const allBought = items.every(item => item.state === 2);
            const newStatus = allBought ? 'Completada' : 'Activa';
            const result = await updateBirthList(listId, { status: newStatus });
            if (result.success) {
                // Update local state
                selectedList.status = newStatus;
                // Call onStatusChange if provided
                if (onStatusChange) {
                    onStatusChange(newStatus);
                }
            } else {
                toast.success('Lista guardada');
            }
            setShowModal(false);
        } catch (error) {
            console.error('Error saving list:', error);
            toast.error('Error al guardar la lista');
        } finally {
            setLoading(false);
        }
    };
    const renderProduct = (item, index) => {
        if (!item?.product?._id) {
            console.warn('Missing product data for item:', item);
            return (
                <div key={item?._id || `error-${index}`} className="p-4 bg-white border-b-1 border-gray-200">
                    <div className="flex items-start">
                        <div className="flex-1">
                            <p className="text-sm text-red-500">{t.errorProductData}</p>
                            <p className="text-xs text-gray-500">{t.productId} {item?._id || t.stateUnknown}</p>
                        </div>
                    </div>
                </div>
            );
        }
        // Hide reserver client info for owner if reserved (state === 1)
        const isOwner = user && selectedList && user._id === selectedList.ownerId;
        const hideUserData = isOwner && item.state === 1;
        // Get product name in correct locale with fallback
        const productName = getProductName(item.product, locale);
        return (
            <div key={item._id} className="p-4 bg-white border-b-1 border-gray-200">
                <div className="flex items-start">
                    <div className="flex-shrink-0 h-16 w-16 bg-gray-100 rounded-md overflow-hidden mr-3">
                        {item.product?.image && (
                            <img
                                src={item.product.image}
                                alt={productName}
                                width="auto"
                                height="auto"
                                className="object-cover w-full h-full"
                            />
                        )}
                    </div>
                    <div className="flex-1">
                        <div className='flex justify-between items-center'>
                            <h4 className="text-sm font-medium text-gray-900">{productName}</h4>
                            {user.role === 'admin' && (
                                <div className="flex items-center space-x-2">
                                    {(item.state === 1 || item.state === 2) && (
                                        <button
                                            onClick={() => moveItem(item, 'left')}
                                            className="px-3 py-1 text-sm rounded-md text-red-600 bg-red-50 hover:bg-red-100 border border-red-200 transition-colors duration-200"
                                            title={item.state === 2 ? (t.cancelarCompra || 'Cancelar compra (Devolución)') : (t.cancelarReserva || 'Cancelar reserva')}
                                        >
                                            {item.state === 2 ? (t.cancelarCompra || 'Devolución') : (t.cancelarReserva || 'Cancelar')}
                                        </button>
                                    )}
                                    {item.state === 0 && (
                                        <>
                                            <button
                                                onClick={() => {
                                                    setCurrentItem(item);
                                                    setDirection('reserve');
                                                    setShowDataModal(true);
                                                }}
                                                className="px-3 py-1 text-sm rounded-md bg-blue-50 text-[#36A9E1] hover:bg-blue-100 border border-blue-200 transition-colors duration-200"
                                                title={t.reservar || 'Reservar producto'}
                                            >
                                                {t.reservar || 'Reservar'}
                                            </button>
                                            <button
                                                onClick={() => {
                                                    setCurrentItem(item);
                                                    setDirection('buy');
                                                    setShowDataModal(true);
                                                }}
                                                className="px-3 py-1 text-sm rounded-md bg-green-50 text-green-600 hover:bg-green-100 border border-green-200 transition-colors duration-200"
                                                title={t.comprar || 'Comprar producto'}
                                            >
                                                {t.comprar || 'Comprar'}
                                            </button>
                                        </>
                                    )}
                                    {item.state === 1 && (
                                        <button
                                            onClick={() => {
                                                setCurrentItem(item);
                                                setDirection('buy');
                                                setShowDataModal(true);
                                            }}
                                            className="px-3 py-1 text-sm rounded-md bg-green-50 text-green-600 hover:bg-green-100 border border-green-200 transition-colors duration-200"
                                            title={t.comprar || 'Comprar producto'}
                                        >
                                            {t.comprar || 'Comprar'}
                                        </button>
                                    )}
                                </div>
                            )}
                        </div>
                        <div className='grid grid-cols-3 gap-2 mt-1'>
                            {/* <p className=''>{item.product?.discount?.finalPrice}€</p> */}
                            <div className="flex flex-col items-start">
                                {item.product.discount?.active ? (
                                    <>
                                        {item.product.discount?.active ? (
                                            <div className="flex flex-col">
                                                <span className="text-sm text-gray-400 line-through">
                                                    {item.product.price_incl_tax.toFixed(2).replace('.', ',')}€
                                                </span>
                                                <span className="text-sm font-medium text-red-600">
                                                    {item.product.discount.finalPrice?.toFixed(2).replace('.', ',')} € {item.product.discount.type === 'percentage' ? `(-${item.product.discount.value}%)` : ''}
                                                </span>
                                            </div>
                                        ) : (
                                            <span className="text-sm text-gray-500">
                                                {item.product.price_incl_tax.toFixed(2).replace('.', ',')} €
                                            </span>
                                        )}
                                    </>
                                ) : (
                                    <p className="text-sm text-gray-900">{parseFloat(item.product.price_incl_tax).toFixed(2).replace('.', ',')} €</p>
                                )}
                            </div>
                            <p className="text-xs text-gray-500">Ref: {item.product.reference || '-'}</p>
                            {/* <p className="text-xs text-gray-500 mt-1">{item.product.brand}</p> */}
                            {user.role === 'admin' && (
                                <p className="text-xs mt-1">
                                    Estado:{" "}
                                    <span
                                        className={`font-medium ${item.state === 0
                                            ? "text-yellow-500"
                                            : item.state === 1
                                                ? "text-[#36A9E1]"
                                                : item.state === 2
                                                    ? "text-green-600"
                                                    : "text-gray-500"
                                            }`}
                                    >
                                        {renderStateLabel(item.state)}
                                    </span>
                                </p>
                            )}
                        </div>
                        {!hideUserData && item.userData && (item.state === 1 || item.state === 2) && (
                            <div className="mt-2 bg-gray-50 p-2 rounded-md border border-gray-200">
                                <div className="flex items-start space-x-2">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4 text-gray-500 mt-0.5">
                                        <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 6a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0ZM4.501 20.118a7.5 7.5 0 0 1 14.998 0A17.933 17.933 0 0 1 12 21.75c-2.676 0-5.216-.584-7.499-1.632Z" />
                                    </svg>
                                    <div className="flex-1">
                                        <p className="text-xs font-medium text-gray-700">{item.userData.name}</p>
                                        <p className="text-xs text-gray-500">{item.userData.email}</p>
                                        {item.userData.phone && (
                                            <p className="text-xs text-gray-500">{item.userData.phone}</p>
                                        )}
                                        {item.userData.message && (
                                            <p className="text-xs text-gray-600 mt-1 bg-white p-1.5 rounded border border-gray-100">
                                                {item.userData.message}
                                            </p>
                                        )}
                                        <p className="text-xs text-gray-400 mt-1">
                                            {new Date(item.userData.date).toLocaleDateString('es-ES', {
                                                year: 'numeric',
                                                month: 'short',
                                                day: 'numeric',
                                                hour: '2-digit',
                                                minute: '2-digit'
                                            })}
                                        </p>
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        );
    };
    if (!showModal || !selectedList) return null;
    return (
        <>
            <div className="fixed inset-0  overflow-y-auto bg-[#00000050] z-[100]  bg-opacity-50 flex items-center justify-center md:p-4 p-1">
                <div className="  bg-white rounded-lg shadow-xl w-full h-auto overflow-hidden ">
                    <div className="p-2 md:p-6 flex flex-col h-full md:min-h-[95vh]">
                        {/* Header */}
                        <div className="flex items-center justify-between md:mb-6 mb-2">
                            <div className="flex items-center">
                                <span className="text-[#36A9E1] mr-2">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
                                        <path strokeLinecap="round" strokeLinejoin="round" d="M21 11.25v8.25a1.5 1.5 0 01-1.5 1.5H5.25a1.5 1.5 0 01-1.5-1.5v-8.25M12 4.875A2.625 2.625 0 109.375 7.5H12m0-2.625V7.5m0-2.625A2.625 2.625 0 1114.625 7.5H12m0 0V21m-8.625-9.75h18c.621 0 1.125-.504 1.125-1.125v-1.5c0-.621-.504-1.125-1.125-1.125h-18c-.621 0-1.125.504-1.125 1.125v1.5c0 .621.504 1.125 1.125 1.125z" />
                                    </svg>
                                </span>
                                <h2 className="text-xl font-bold text-gray-800">{t.details}</h2>
                            </div>
                            <div className="flex items-center space-x-2">
                                <button
                                    onClick={() => setShowModal(false)}
                                    className="text-gray-500 hover:text-gray-700"
                                >
                                    <FiX size={24} />
                                </button>
                            </div>
                        </div>
                        {/* Main information cards */}
                        <div>
                            <div className="hidden md:flex items-center mb-4 ">
                                <span className="text-[#36A9E1] mr-2">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                                        <path strokeLinecap="round" strokeLinejoin="round" d="M15 9h3.75M15 12h3.75M15 15h3.75M4.5 19.5h15a2.25 2.25 0 002.25-2.25V6.75A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25v10.5A2.25 2.25 0 004.5 19.5zm6-10.125a1.875 1.875 0 11-3.75 0 1.875 1.875 0 013.75 0zm1.294 6.336a6.721 6.721 0 01-3.17.789 6.721 6.721 0 01-3.168-.789 3.376 3.376 0 016.338 0z" />
                                    </svg>
                                </span>
                                <h3 className="text-md font-semibold text-gray-800">{t.info}</h3>
                            </div>
                            <div className='hidden md:flex flex-row space-x-4 mb-4'>
                                <div className="bg-white rounded-lg border border-gray-200 md:w-[500px] ">
                                    <div className="flex flex-row space-x-2 justify-between p-4 space-y-3">
                                        <div>
                                            <span className="block text-xs font-medium text-gray-500">{t.reference}</span>
                                            <p className="text-sm text-gray-900 mt-1">{selectedList.reference}</p>
                                        </div>
                                        <div>
                                            <span className="block text-xs font-medium text-gray-500">{t.babyName}</span>
                                            <p className="text-sm text-gray-900 mt-1">{selectedList.babyName}</p>
                                        </div>
                                        <div>
                                            <span className="block text-xs font-medium text-gray-500">{t.visibility}</span>
                                            <p className="text-sm text-gray-900 mt-1">{selectedList.isPublic ? t.public : t.private}</p>
                                        </div>
                                        {selectedList.description && (
                                            <div>
                                                <span className="block text-xs font-medium text-gray-500">{t.description}</span>
                                                <p className="text-sm text-gray-900 mt-1">{selectedList.description}</p>
                                            </div>
                                        )}
                                    </div>
                                </div>
                                <div className="flex-1">
                                    <div className="grid grid-cols-4 gap-4">
                                        <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                                            <div className="flex items-center mb-2">
                                                <span className="text-gray-400 mr-2">
                                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                                                        <path strokeLinecap="round" strokeLinejoin="round" d="M6.75 3v2.25M17.25 3v2.25M3 18.75V7.5a2.25 2.25 0 012.25-2.25h13.5A2.25 2.25 0 0121 7.5v11.25a2.25 2.25 0 01-2.25 2.25h-15a2.25 2.25 0 00-2.25-2.25v-7.5A2.25 2.25 0 015.25 9h13.5A2.25 2.25 0 0121 11.25v7.5" />
                                                    </svg>
                                                </span>
                                                <h3 className="text-sm font-medium text-gray-500">{t.date}</h3>
                                            </div>
                                            <p className="text-md font-medium">{selectedList.creationDate}</p>
                                        </div>
                                        <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                                            <div className="flex items-center mb-2">
                                                <span className="text-green-500 mr-2">
                                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                                                        <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v12m-3-2.818l.879.659c1.171.879 3.07.879 4.242 0 1.172-.879 1.172-2.303 0-3.182C13.536 12.219 12.768 12 12 12c-.725 0-1.45-.22-2.003-.659-1.106-.879-1.106-2.303 0-3.182s2.9-.879 4.006 0l.415.33M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                                    </svg>
                                                </span>
                                                <h3 className="text-sm font-medium text-gray-500">{t.total}</h3>
                                            </div>
                                            <p className="text-md font-medium">{selectedList.products} {t.productos}</p>
                                        </div>
                                        <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                                            <div className="flex items-center mb-2">
                                                <span className="text-purple-500 mr-2">
                                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                                                        <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 8.25h19.5M2.25 9h19.5m-16.5 5.25h6m-6 2.25h3m-3.75 3h15a2.25 2.25 0 002.25-2.25V6.75A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25v10.5A2.25 2.25 0 004.5 19.5z" />
                                                    </svg>
                                                </span>
                                                <h3 className="text-sm font-medium text-gray-500">{t.dueDate}</h3>
                                            </div>
                                            <p className="text-md font-medium">{selectedList.dueDate}</p>
                                        </div>
                                        <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                                            <div className="flex items-center mb-2">
                                                <span className="text-[#36A9E1] mr-2">
                                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                                                        <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                                    </svg>
                                                </span>
                                                <h3 className="text-sm font-medium text-gray-500">{t.status}</h3>
                                            </div>
                                            <div>
                                                <span
                                                    className={`inline-block px-2 py-1 rounded-full text-xs font-medium ${selectedList.status === 'Activa' ? 'bg-green-100 text-green-800' :
                                                        selectedList.status === 'Completada' ? 'bg-blue-100 text-[#36A9E1]' :
                                                            'bg-red-100 text-red-800'
                                                        }`}
                                                >
                                                    {selectedList.status}
                                                </span>
                                                <p className="text-xs text-gray-500 mt-1">
                                                    {selectedList.status === t.active
                                                        ? t.activeDesc
                                                        : selectedList.status === t.completed
                                                            ? t.completedDesc
                                                            : t.inactiveDesc}
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className='md:hidden grid grid-cols-2 mb-2 h-full overflow-auto p-1 mt-2'>
                                <div className='mb-2'>
                                    <span className="block text-xs font-medium text-gray-500">{t.reference}</span>
                                    <p className="text-sm text-gray-900 ">{selectedList.reference}</p>
                                </div>
                                <div className='mb-2'>
                                    <span className="block text-xs font-medium text-gray-500">{t.babyName}</span>
                                    <p className="text-sm text-gray-900">{selectedList.babyName}</p>
                                </div>
                                <div className='mb-2'>
                                    <span className="block text-xs font-medium text-gray-500">{t.visibility}</span>
                                    <p className="text-sm text-gray-900">{selectedList.isPublic ? t.public : t.private}</p>
                                </div>
                                <div className='mb-2'>
                                    <span className="block text-xs font-medium text-gray-500">{t.date}</span>
                                    <p className="text-sm text-gray-900">{selectedList.creationDate}</p>
                                </div>
                                <div className='mb-2'>
                                    <span className="block text-xs font-medium text-gray-500">{t.total}</span>
                                    <p className="text-sm text-gray-900">{selectedList.products} {t.productos}</p>
                                </div>
                                <div className='mb-2'>
                                    <span className="block text-xs font-medium text-gray-500">{t.dueDate}</span>
                                    <p className="text-sm text-gray-900">{selectedList.dueDate}</p>
                                </div>
                            </div>
                            {/* Products sections */}
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 flex-1  ">
                                {/* Pending Items - Always shown, but for owner also show reserved with tag */}
                                <div className="flex flex-col">
                                    <div className="space-y-4 md:mb-4">
                                        <div className="flex items-center">
                                            <span className="text-[#36A9E1] mr-2">
                                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                                                    <path strokeLinecap="round" strokeLinejoin="round" d="M20.25 7.5l-.625 10.632a2.25 2.25 0 01-2.247 2.118H6.622a2.25 2.25 0 01-2.247-2.118L3.75 7.5M10 11.25h4M3.375 7.5h17.25c.621 0 1.125-.504 1.125-1.125v-1.5c0-.621-.504-1.125-1.125-1.125H3.375c-.621 0-1.125.504-1.125 1.125v1.5c0 .621.504 1.125 1.125 1.125z" />
                                                </svg>
                                            </span>
                                            <h3 className="text-md font-semibold text-gray-800">{t.pendingProducts}</h3>
                                        </div>
                                        <div className="hidden md:block relative">
                                            <input
                                                type="text"
                                                placeholder={locale === 'ca' ? "Cercar producte" : "Buscar producto"}
                                                value={pendingSearch}
                                                onChange={(e) => setPendingSearch(e.target.value)}
                                                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded text-sm"
                                            />
                                            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4 text-gray-400">
                                                    <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z" />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="bg-white rounded-lg border border-gray-200 overflow-auto h-[25vh] md:max-h-[50vh] md:flex-1 md:min-h-[50vh]">
                                        {itemsLoading ? (
                                            <div className="flex justify-center items-center py-10">
                                                <div className="animate-spin rounded-full h-10 w-10 border-t-1 border-b-1 border-[#36A9E1]"></div>
                                            </div>
                                        ) : (() => {
                                            // For the owner, show reserved products in pending with a tag
                                            const isOwner = user && selectedList && user._id === selectedList.ownerId;
                                            let pendingItems = getPendingItems();
                                            let reservedItems = [];
                                            const isAdmin = user && user.role === 'admin';
                                            if (!isAdmin && isOwner) {
                                                reservedItems = getReservedItems();
                                            }
                                            // For admin, do NOT show reserved products in pending or with tag
                                            if (isAdmin) {
                                                pendingItems = pendingItems.filter(item => item.state !== 1);
                                            }
                                            const allItems = (!isAdmin && isOwner) ? [...pendingItems, ...reservedItems] : pendingItems;
                                            if (allItems.length === 0) {
                                                return (
                                                    <div className="text-center py-10 h-[30vh] md:h-full">
                                                        <p className="text-gray-500">{t.noPending}</p>
                                                    </div>
                                                );
                                            }
                                            return (
                                                <div className="divide-y divide-gray-200 h-full overflow-y-auto">
                                                    {allItems.map((item, index) => {
                                                        // If owner and item is reserved, add tag and hide reserver info
                                                        const isReserved = !isAdmin && isOwner && reservedItems.some(r => r._id === item._id);
                                                        // If reserved, render product without reserver info
                                                        if (isReserved) {
                                                            return (
                                                                <div key={item._id || index} className="relative">
                                                                    {renderProduct({ ...item, reservedBy: undefined, reservedData: undefined }, index)}
                                                                    <span className="absolute top-2 right-2 bg-yellow-200 text-yellow-800 text-xs font-semibold px-2 py-0.5 rounded">{t.reservedTag}</span>
                                                                </div>
                                                            );
                                                        }
                                                        return (
                                                            <div key={item._id || index} className="relative">
                                                                {renderProduct(item, index)}
                                                            </div>
                                                        );
                                                    })}
                                                </div>
                                            );
                                        })()}
                                    </div>
                                </div>
                                {/* Bought Items - Always shown */}
                                <div className="flex flex-col">
                                    <div className="space-y-4 md:mb-4">
                                        <div className="flex items-center">
                                            <span className="text-[#36A9E1] mr-2">
                                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                                                    <path strokeLinecap="round" strokeLinejoin="round" d="M20.25 7.5l-.625 10.632a2.25 2.25 0 01-2.247 2.118H6.622a2.25 2.25 0 01-2.247-2.118L3.75 7.5M10 11.25h4M3.375 7.5h17.25c.621 0 1.125-.504 1.125-1.125v-1.5c0-.621-.504-1.125-1.125-1.125H3.375c-.621 0-1.125.504-1.125 1.125v1.5c0 .621.504 1.125 1.125 1.125z" />
                                                </svg>
                                            </span>
                                            <h3 className="text-md font-semibold text-gray-800">{t.boughtProducts}</h3>
                                        </div>
                                        <div className="hidden md:block relative">
                                            <input
                                                type="text"
                                                placeholder={locale === 'ca' ? "Cercar producte" : "Buscar producto"}
                                                value={boughtSearch}
                                                onChange={(e) => setBoughtSearch(e.target.value)}
                                                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded text-sm"
                                            />
                                            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4 text-gray-400">
                                                    <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z" />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="bg-white rounded-lg border border-gray-200 overflow-auto h-[25vh] md:max-h-[50vh] md:flex-1">

                                        {itemsLoading ? (
                                            <div className="flex justify-center items-center py-10">
                                                <div className="animate-spin rounded-full h-10 w-10 border-t-1 border-b-1 border-[#36A9E1]"></div>
                                            </div>
                                        ) : getBoughtItems().length === 0 ? (
                                            <div className="text-center py-10 h-[30vh] md:h-full">
                                                <p className="text-gray-500">{t.noBought}</p>
                                            </div>
                                        ) : (
                                            <div className="divide-y divide-gray-200 h-full overflow-y-auto">
                                                {getBoughtItems().map((item, index) => renderProduct(item, index))}
                                            </div>
                                        )}
                                    </div>
                                </div>
                                {/* Third column - Different based on user role */}
                                {user.role === 'admin' ? (
                                    /* Admin view - Reserved Items */
                                    <div className="hidden md:block">
                                        <div className="flex flex-col">
                                            <div className="space-y-4 md:mb-4">
                                                <div className="flex items-center">
                                                    <span className="text-[#36A9E1] mr-2">
                                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                                                            <path strokeLinecap="round" strokeLinejoin="round" d="M20.25 7.5l-.625 10.632a2.25 2.25 0 01-2.247 2.118H6.622a2.25 2.25 0 01-2.247-2.118L3.75 7.5M10 11.25h4M3.375 7.5h17.25c.621 0 1.125-.504 1.125-1.125v-1.5c0-.621-.504-1.125-1.125-1.125H3.375c-.621 0-1.125.504-1.125 1.125v1.5c0 .621.504 1.125 1.125 1.125z" />
                                                        </svg>
                                                    </span>
                                                    <h3 className="text-md font-semibold text-gray-800">{t.reservedProducts}</h3>
                                                </div>
                                                <div className="hidden md:block relative">
                                                    <input
                                                        type="text"
                                                        placeholder={locale === 'ca' ? "Cercar producte" : "Buscar producto"}
                                                        value={reservedSearch}
                                                        onChange={(e) => setReservedSearch(e.target.value)}
                                                        className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded text-sm"
                                                    />
                                                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4 text-gray-400">
                                                            <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z" />
                                                        </svg>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="bg-white rounded-lg border border-gray-200 overflow-auto h-[25vh] md:max-h-[50vh] md:flex-1">
                                                {itemsLoading ? (
                                                    <div className="flex justify-center items-center py-10">
                                                        <div className="animate-spin rounded-full h-10 w-10 border-t-1 border-b-1 border-[#36A9E1]"></div>
                                                    </div>
                                                ) : getReservedItems().length === 0 ? (
                                                    <div className="text-center py-10 h-[30vh] md:h-full">
                                                        <p className="text-gray-500">{t.noReserved}</p>
                                                    </div>
                                                ) : (
                                                    <div className="divide-y divide-gray-200 h-full overflow-y-auto">
                                                        {getReservedItems().map((item, index) => renderProduct(item, index))}
                                                    </div>
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                ) : (
                                    /* Owner view - Progress */
                                    <div className="hidden md:flex flex-col">
                                        <div className="flex items-center mb-4">
                                            <span className="text-[#36A9E1] mr-2">
                                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                                                    <path strokeLinecap="round" strokeLinejoin="round" d="M3 13.125C3 12.504 3.504 12 4.125 12h2.25c.621 0 1.125.504 1.125 1.125v6.75C7.5 20.496 6.996 21 6.375 21h-2.25A1.125 1.125 0 013 19.875v-6.75zM9.75 8.625c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125v11.25c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V8.625zM16.5 4.125c0-.621.504-1.125 1.125-1.125h2.25C20.496 3 21 3.504 21 4.125v15.75c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V4.125z" />
                                                </svg>
                                            </span>
                                            <h3 className="text-md font-semibold text-gray-800">{t.progress}</h3>
                                        </div>
                                        <div className="bg-white rounded-lg border border-gray-200 p-4 h-[120px] md:h-[300px]">
                                            <div className="mb-6">
                                                <div className="flex justify-between text-sm mb-2">
                                                    <span className="text-xs text-gray-500">{t.progresoTotal}</span>
                                                    <span className="text-xs font-medium">{calculateProgress()}%</span>
                                                </div>
                                                <div className="w-full bg-gray-200 rounded-full h-2.5">
                                                    <div
                                                        className={`h-2.5 rounded-full ${calculateProgress() >= 100 ? 'bg-[#36A9E1]' :
                                                            calculateProgress() >= 75 ? 'bg-[#36A9E1]' :
                                                                calculateProgress() >= 50 ? 'bg-yellow-500' :
                                                                    'bg-green-500'
                                                            }`}
                                                        style={{ width: `${calculateProgress()}%` }}
                                                    />
                                                </div>
                                                <div className=" md:hidden flex justify-between mt-4">
                                                    <div className="text-sm font-bold text-gray-800">{t.totalProducts}: {selectedList.products}</div>
                                                    <div className="text-sm font-bold text-gray-800">{t.receivedProducts}: {selectedList.purchased}</div>
                                                </div>
                                            </div>
                                            <div className="hidden md:grid grid-cols-2 gap-4 text-center">
                                                <div className="bg-gray-50 p-4 rounded-lg">
                                                    <div className="text-4xl font-bold text-[#36A9E1]">{selectedList.products}</div>
                                                    <div className="text-xs text-gray-500 mt-1">{t.totalProducts}</div>
                                                </div>
                                                <div className="bg-gray-50 p-4 rounded-lg">
                                                    <div className="text-4xl font-bold text-green-500">{selectedList.purchased}</div>
                                                    <div className="text-xs text-gray-500 mt-1">{t.receivedProducts}</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                )}
                            </div>
                        </div>
                        {/* Footer */}
                        <div className="border-t border-gray-200 mt-6 pt-4">
                            <div className="flex justify-end">
                                <button
                                    onClick={handleSaveList}
                                    className="inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-[#36A9E1] border border-transparent rounded-md hover:bg-[#36A9E1]/80 focus:outline-none"
                                >
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 mr-2">
                                        <path strokeLinecap="round" strokeLinejoin="round" d="M9 3.75H6.912a2.25 2.25 0 00-2.15 1.588L2.35 13.177a2.25 2.25 0 00-.1.661V18a2.25 2.25 0 002.25 2.25h15A2.25 2.25 0 0021.75 18v-4.162c0-.224-.034-.447-.1-.661L19.24 5.338a2.25 2.25 0 00-2.15-1.588H15M2.25 13.5h3.86a2.25 2.25 0 012.012 1.244l.256.512a2.25 2.25 0 002.013 1.244h3.218a2.25 2.25 0 002.013-1.244l.256-.512a2.25 2.25 0 012.013-1.244h3.859M12 3v8.25m0 0l-3-3m3 3l3-3" />
                                    </svg>
                                    {t.save}
                                </button>
                                {/* <button
                                type="button"
                                onClick={() => setShowModal(false)}
                                className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none"
                                >
                                Cerrar
                                </button> */}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {/* Cancel Confirmation Modal */}
            {
                showCancelConfirm && cancelItem && (
                    <div className="fixed inset-0 bg-[#00000050] bg-opacity-50 flex items-center justify-center z-[101]">
                        <div className="bg-white p-6 rounded-lg w-full max-w-sm">
                            <div className="flex flex-col items-center justify-center">
                                <h3 className="text-lg font-medium mb-4 text-center text-red-600">{t.cancelarCompra || '¿Cancelar compra?'}</h3>
                                <p className="text-sm text-gray-700 mb-6 text-center">¿Estás seguro que quieres cancelar la compra de este producto? Esta acción no se puede deshacer.</p>
                                <div className="flex gap-3 justify-center">
                                    <button
                                        onClick={() => setShowCancelConfirm(false)}
                                        className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#36A9E1]">
                                        Cancelar
                                    </button>
                                    <button
                                        onClick={async () => {
                                            setShowCancelConfirm(false);
                                            setLoading(true);
                                            const listId = selectedList.rawData?._id || selectedList._id;
                                            if (!listId) {
                                                toast.error('Error: ID de lista no encontrado');
                                                setLoading(false);
                                                return;
                                            }
                                            try {
                                                const result = await updateBirthListItemState(listId, cancelItem._id, 0, null);
                                                if (result.success) {
                                                    const updatedItems = items.map(i =>
                                                        i._id === cancelItem._id ? result.data : i
                                                    );
                                                    setItems(updatedItems);
                                                    toast.success('Producto cancelado correctamente');
                                                    // Send cancellation email via API
                                                    try {
                                                        const response = await fetch('/api/send-gift-notification', {
                                                            method: 'POST',
                                                            headers: {
                                                                'Content-Type': 'application/json',
                                                            },
                                                            body: JSON.stringify({
                                                                selectedList: selectedList,
                                                                action: 'cancel',
                                                                cancelledItem: { ...result.data, state: 0 }
                                                            })
                                                        });
                                                        let data = {};
                                                        try {
                                                            data = await response.json();
                                                        } catch (jsonError) {
                                                            console.error('Error parsing API response:', jsonError);
                                                        }
                                                        // console.log('Cancel notification API response:', response.status, data);
                                                        if (response.ok && data.success) {
                                                            toast.success('Notificación de cancelación enviada correctamente');
                                                        } else {
                                                            toast.error('Error al enviar la notificación de cancelación: ' + (data.error || response.status));
                                                        }
                                                    } catch (emailError) {
                                                        console.error('Error sending cancel notification:', emailError);
                                                        toast.error('Error al enviar la notificación de cancelación: ' + (emailError.message || 'Error desconocido'));
                                                    }
                                                }
                                            } catch (error) {
                                                console.error('Error updating item:', error);
                                                toast.error(error.message || 'Error al cancelar el producto');
                                            } finally {
                                                setLoading(false);
                                                setCancelItem(null);
                                            }
                                        }}
                                        className="px-4 py-2 text-sm font-medium text-white bg-red-600 border border-transparent rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-600">
                                        Sí, cancelar
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                )
            }

            {/* Data Collection Modal */}
            {
                showDataModal && currentItem && (
                    <div className="fixed inset-0 bg-[#00000050] bg-opacity-50 flex items-center justify-center z-[101] p-1">
                        <div className="bg-white p-6 rounded-lg w-full max-w-md">
                            <div className="flex justify-between items-center mb-4">
                                <h3 className="text-lg font-medium">{t.buyerData}</h3>
                                <button
                                    onClick={() => setShowDataModal(false)}
                                    className="text-gray-500 hover:text-gray-700"
                                >
                                    <FiX className="w-5 h-5" />
                                </button>
                            </div>
                            <div className="space-y-4">
                                <div>
                                    <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                                        {t.name}
                                    </label>
                                    <input
                                        type="text"
                                        id="name"
                                        name="name"
                                        value={userData.name}
                                        onChange={handleUserDataChange}
                                        className="mt-1 block w-full rounded-md border-gray-300 focus:border-[#36A9E1] focus:ring-[#36A9E1] sm:text-sm p-2 border"
                                        required
                                    />
                                </div>
                                <div>
                                    <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                                        {t.email}
                                    </label>
                                    <input
                                        type="email"
                                        id="email"
                                        name="email"
                                        value={userData.email}
                                        onChange={handleUserDataChange}
                                        className="mt-1 block w-full rounded-md border-gray-300 focus:border-[#36A9E1] focus:ring-[#36A9E1] sm:text-sm p-2 border"
                                    // required
                                    />
                                </div>
                                <div>
                                    <label htmlFor="phone" className="block text-sm font-medium text-gray-700">
                                        {t.phone}
                                    </label>
                                    <input
                                        type="tel"
                                        id="phone"
                                        name="phone"
                                        value={userData.phone}
                                        onChange={handleUserDataChange}
                                        className="mt-1 block w-full rounded-md border-gray-300 focus:border-[#36A9E1] focus:ring-[#36A9E1] sm:text-sm p-2 border"
                                    />
                                </div>
                                <div>
                                    <label htmlFor="message" className="block text-sm font-medium text-gray-700">
                                        {t.message}
                                    </label>
                                    <textarea
                                        id="message"
                                        name="message"
                                        value={userData.message}
                                        onChange={handleUserDataChange}
                                        rows={3}
                                        className="mt-1 block w-full rounded-md border-gray-300 focus:border-[#36A9E1] focus:ring-[#36A9E1] sm:text-sm p-2 border"
                                    ></textarea>
                                </div>
                            </div>
                            <div className="mt-6 flex justify-end space-x-3">
                                <button
                                    onClick={() => setShowDataModal(false)}
                                    className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#36A9E1]">
                                    {t.cancel}
                                </button>
                                <button
                                    onClick={confirmStateChange}
                                    className="px-4 py-2 text-sm font-medium text-white bg-[#36A9E1] border border-transparent rounded-md hover:bg-[#36A9E1] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#36A9E1]">
                                    {t.save}
                                </button>
                            </div>
                        </div>
                    </div>
                )
            }
        </>
    );
}