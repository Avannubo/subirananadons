"use client";
import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import CryptoJS from 'crypto-js';
export default function ModalTPV({ isOpen, onClose, orderData }) {
    const [cartItems, setCartItems] = useState(orderData?.cartProducts || []);
    const [isProcessingPayment, setIsProcessingPayment] = useState(false);
    const [paymentStatus, setPaymentStatus] = useState(null);
    // Get locale from URL or default to 'ca'
    let locale = 'ca';
    if (typeof window !== 'undefined') {
        const pathLocale = window.location.pathname.split('/')[1];
        if (['ca', 'es'].includes(pathLocale)) locale = pathLocale;
    }
    const translations = {
        ca: {
            processingPayment: "Pagament en procés...",
            pleaseWait: "Si us plau, espera mentre processem el teu pagament.",
            paymentSuccess: "Pagament realitzat!",
            paymentCompleted: "El teu pagament s'ha completat amb èxit!",
            orderSummaryEmail: "El resum de la comanda arribarà al teu correu electrònic.",
            home: "Inici",
            shop: "Botiga",
            contact: "Contacte",
            paymentError: "Error en el pagament",
            paymentProblem: "Hi ha hagut un problema en processar el teu pagament. Torna-ho a intentar.",
            close: "Tancar",
            orderSummary: "Resum de la Comanda",
            product: "Producte",
            quantity: "Quantitat",
            price: "Preu",
            total: "Total",
            totalOrderPrice: "Preu total de la comanda:",
            totalDiscount: "Total descomptes",
            confirmPayment: "Confirmar Pagament",
            cancel: "Cancel·lar"
        },
        es: {
            processingPayment: "Pago en proceso...",
            pleaseWait: "Por favor, espera mientras procesamos tu pago.",
            paymentSuccess: "¡Pago realizado!",
            paymentCompleted: "¡Tu pago ha sido completado con éxito!",
            orderSummaryEmail: "El resumen del pedido llegará a tu correo electrónico.",
            home: "Inicio",
            shop: "Tienda",
            contact: "Contacto",
            paymentError: "Error en el pago",
            paymentProblem: "Hubo un problema al procesar tu pago. Inténtalo de nuevo.",
            close: "Cerrar",
            orderSummary: "Resumen del Pedido",
            product: "Producto",
            quantity: "Cantidad",
            price: "Precio",
            total: "Total",
            totalOrderPrice: "Precio total del pedido:",
            totalDiscount: "Total descuentos",
            confirmPayment: "Confirmar Pago",
            cancel: "Cancelar"
        }
    };
    useEffect(() => {
        if (orderData && Array.isArray(orderData.cartProducts)) {
            setCartItems(orderData.cartProducts);
        }
    }, [orderData]);
    const getItemPrice = (item) => {
        // Get base price
        let basePrice = typeof item.priceValue === 'number' ? item.priceValue :
            (typeof item.price === 'number' ? item.price :
                parseFloat(String(item.price || "0").replace(/[^\d.,]/g, '').replace(',', '.')));
        // Check if there's an active discount
        if (item.discount && item.discount.active) {
            const now = new Date();
            const startDate = item.discount.startDate ? new Date(item.discount.startDate) : null;
            const endDate = item.discount.endDate ? new Date(item.discount.endDate) : null;
            // Verify if discount is currently valid
            if ((!startDate || now >= startDate) && (!endDate || now <= endDate)) {
                if (item.discount.type === 'percentage') {
                    return basePrice * (1 - (item.discount.value / 100));
                } else if (item.discount.type === 'fixed') {
                    return Math.max(0, basePrice - item.discount.value);
                }
            }
        }
        return basePrice;
    };
    const calculateTotal = () => {
        return cartItems.reduce((sum, item) => {
            const price = getItemPrice(item);
            return sum + (price * (item.quantity || 1));
        }, 0);
    };
    const stringBase64Encode = (input) => {
        let utf8Input = CryptoJS.enc.Utf8.parse(input);
        return CryptoJS.enc.Base64.stringify(utf8Input);
    };
    const base64Decode = (input) => {
        return CryptoJS.enc.Base64.parse(input);
    };
    const des_encrypt = (message, key) => {
        let ivArray = [0, 0, 0, 0, 0, 0, 0, 0];
        let IV = ivArray.map(item => String.fromCharCode(item)).join("");
        let encode_str = CryptoJS.TripleDES.encrypt(message, key, {
            iv: CryptoJS.enc.Utf8.parse(IV),
            mode: CryptoJS.mode.CBC,
            padding: CryptoJS.pad.ZeroPadding
        });
        return encode_str.toString();
    };
    const calcularFirma = () => {
        const total = calculateTotal();
        let cleanPrecioTotal = (total * 100).toString(); // Convert to cents and string
        let merchantOrder = orderData?.orderId || String(Date.now()).substring(0, 12).padStart(4, '0');
        // Create data object for the payment request
        let data = {
            "DS_MERCHANT_AMOUNT": cleanPrecioTotal,
            "DS_MERCHANT_CURRENCY": "978",
            "DS_MERCHANT_MERCHANTCODE": "352203061",
            "DS_MERCHANT_ORDER": merchantOrder,
            "DS_MERCHANT_TERMINAL": "2",
            "DS_MERCHANT_TRANSACTIONTYPE": "0",
            "DS_MERCHANT_URLOK": `${window.location.origin}/cart/order/success`,
            "DS_MERCHANT_URLKO": `${window.location.origin}/cart/order/failed`
        };
        // Encode parameters and calculate signature
        let encodedParameters = stringBase64Encode(JSON.stringify(data));
        let encodedSignature = "sq7HjrUOBfKmC576ILgskD5srU870gJ7";
        let encodedSignatureDES = des_encrypt(merchantOrder, base64Decode(encodedSignature));
        let encodedDsSignature = CryptoJS.HmacSHA256(encodedParameters, base64Decode(encodedSignatureDES));
        let dsSignature = CryptoJS.enc.Base64.stringify(encodedDsSignature);
        // Populate form fields safely
        if (typeof document !== 'undefined') {
            const form = document.forms["pago"];
            if (form) {
                if (form.Ds_MerchantParameters) form.Ds_MerchantParameters.value = encodedParameters;
                if (form.Ds_Signature) form.Ds_Signature.value = dsSignature;
            }
        }
    };
    const handlePaymentProcess = async () => {
        setIsProcessingPayment(true);
        try {
            calcularFirma();
            if (typeof document !== 'undefined' && document.forms["pago"]) {
                document.forms["pago"].submit();
            }
        } catch (error) {
            setPaymentStatus('KO');
            console.error("Payment processing error:", error);
        } finally {
            setIsProcessingPayment(false);
        }
    };
    const handleCloseModal = () => {
        const cleanUrl = window.location.origin + window.location.pathname;
        window.history.replaceState(null, '', cleanUrl);
        window.location.reload();
    };
    return isOpen || paymentStatus ? (
        <div className="fixed inset-0 flex flex-wrap justify-center items-center w-full h-full z-[999] bg-[rgba(0,0,0,0.45)] overflow-auto font-[sans-serif]">
            <div className="z-[1000] max-w-4xl w-full mx-auto bg-white rounded-2xl shadow-2xl border border-gray-100 px-0 md:px-0">
                {isProcessingPayment ? (
                    <div className="p-8 rounded-2xl shadow-xl text-center bg-white">
                        <h2 className="text-2xl font-bold text-[#3f93ba]">{translations[locale].processingPayment}</h2>
                        <p className="text-base mt-2 text-gray-700">{translations[locale].pleaseWait}</p>
                        <div className="mt-6 flex justify-center">
                            <span className="inline-block w-8 h-8 border-4 border-[#3f93ba] border-t-transparent rounded-full animate-spin"></span>
                        </div>
                    </div>
                ) : paymentStatus === 'OK' ? (
                    <div className="p-8 rounded-2xl shadow-xl text-center bg-white">
                        <h2 className="text-2xl font-bold text-green-600">{translations[locale].paymentSuccess}</h2>
                        <p className="text-base mt-2 text-gray-700">{translations[locale].paymentCompleted}</p>
                        <h2 className="text-xl mt-4 font-semibold text-[#3f93ba]">{translations[locale].orderSummaryEmail}</h2>
                        <div className='flex flex-row justify-center gap-3 mt-6'>
                            <Link href="/" className="bg-[#3f93ba] hover:bg-[#008fa8d5] text-white px-5 py-2 rounded-lg font-semibold transition-colors duration-150">
                                {translations[locale].home}
                            </Link>
                            <Link href="/products" className="bg-[#3f93ba] hover:bg-[#008fa8d5] text-white px-5 py-2 rounded-lg font-semibold transition-colors duration-150">
                                {translations[locale].shop}
                            </Link>
                            <Link href="/about/contacto" className="bg-[#3f93ba] hover:bg-[#008fa8d5] text-white px-5 py-2 rounded-lg font-semibold transition-colors duration-150">
                                {translations[locale].contact}
                            </Link>
                        </div>
                    </div>
                ) : paymentStatus === 'KO' ? (
                    <div className="p-8 rounded-2xl shadow-xl text-center bg-white">
                        <h2 className="text-2xl font-bold text-red-500">{translations[locale].paymentError}</h2>
                        <p className="text-base mt-2 text-gray-700">{translations[locale].paymentProblem}</p>
                        <div className="flex flex-row justify-center gap-3 mt-6">
                            <button onClick={handleCloseModal} className="bg-gray-400 hover:bg-gray-500 text-white px-5 py-2 rounded-lg font-semibold transition-colors duration-150">
                                {translations[locale].close}
                            </button>
                        </div>
                    </div>
                ) : (
                    <div className="px-6 md:px-12 py-8 rounded-2xl shadow-xl bg-white">
                        <h2 className="text-2xl font-bold text-[#3f93ba] mb-4">{translations[locale].orderSummary}</h2>
                        <div className="overflow-x-auto rounded-lg border border-gray-100">
                            <table className="w-full table-auto border-collapse text-sm">
                                <thead>
                                    <tr className="bg-gray-50 text-gray-700">
                                        <th className="px-4 py-2 font-semibold">{translations[locale].product}</th>
                                        <th className="px-4 py-2 font-semibold">{translations[locale].quantity}</th>
                                        <th className="px-4 py-2 font-semibold">{translations[locale].price}</th>
                                        <th className="px-4 py-2 font-semibold">{translations[locale].total}</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {cartItems.map((product) => (
                                        <tr key={product.id} className="border-b border-b-gray-100 last:border-b-0">
                                            <td className="px-4 py-2 flex items-center gap-3">
                                                {product.image && (
                                                    <img src={product.image} alt={product.name} className="w-32 h-32 object-cover rounded-lg border border-gray-200 bg-gray-50" />
                                                )}
                                                <div>
                                                    <div className="font-medium text-xl text-gray-900">{product.name}</div>
                                                    <div className="text-xs text-gray-500">{product.brand}{product.brand && product.category ? ' - ' : ''}{product.category}</div>
                                                </div>
                                            </td>
                                            <td className="px-4 py-2 text-lg text-center">{product.quantity}</td>
                                            <td className="px-4 py-2 text-lg">
                                                {product.discount && product.discount.active ? (
                                                    <div className="flex flex-col">
                                                        <span className="text-gray-400 line-through text-sm">
                                                            {typeof product.priceValue === 'number' ? product.priceValue.toFixed(2) : product.price}€
                                                        </span>
                                                        <span className="text-red-600">
                                                            {getItemPrice(product).toFixed(2)}€
                                                            <span className="ml-1 text-xs bg-red-100 text-red-600 px-1 py-0.5 rounded">
                                                                -{product.discount.value}%
                                                            </span>
                                                        </span>
                                                    </div>
                                                ) : (
                                                    <span>
                                                        {typeof product.priceValue === 'number' ? product.priceValue.toFixed(2) : product.price}{typeof product.priceValue === 'number' ? '€' : ''}
                                                    </span>
                                                )}
                                            </td>
                                            <td className="px-4 py-2 font-medium text-lg">
                                                {(getItemPrice(product) * (product.quantity || 1)).toFixed(2)}€
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                        <div className="mt-6 text-right">
                            {cartItems.some(item => item.discount?.active) && (
                                <p className="text-base text-red-600 mb-1">
                                    {translations[locale].totalDiscount}: -{cartItems.reduce((total, item) => {
                                        if (item.discount && item.discount.active) {
                                            const originalPrice = typeof item.priceValue === 'number' ? item.priceValue :
                                                parseFloat(String(item.price || "0").replace(/[^\d.,]/g, '').replace(',', '.'));
                                            const discountedPrice = getItemPrice(item);
                                            return total + ((originalPrice - discountedPrice) * (item.quantity || 1));
                                        }
                                        return total;
                                    }, 0).toFixed(2)}€
                                </p>
                            )}
                            <p className="text-lg font-bold text-gray-900">
                                {translations[locale].totalOrderPrice} {calculateTotal().toFixed(2)}€
                            </p>
                        </div>
                        <div className="flex flex-row justify-center gap-3 mt-8">
                            <button onClick={handlePaymentProcess} className="bg-[#36A9E1] hover:bg-[#008fa8d5] text-white px-6 py-2 rounded-lg font-normal transition-colors duration-150 h-[42px]">
                                {translations[locale].confirmPayment}
                            </button>
                            <button onClick={onClose} className="bg-gray-400 hover:bg-gray-500 text-white px-6 py-2 rounded-lg font-normal transition-colors duration-150 h-[42px]">
                                {translations[locale].cancel}
                            </button>
                        </div>
                    </div>
                )}
                {/* Hidden payment form for Redsys */}
                <form className="hidden" name="pago" action="https://sis-t.redsys.es:25443/sis/realizarPago" method="POST" >
                    <textarea name="Ds_MerchantParameters" cols="80" rows="5" readOnly></textarea>
                    <input type="text" name="Ds_Signature" defaultValue="" size="100" readOnly />
                    <input type="text" name="Ds_SignatureVersion" defaultValue="HMAC_SHA256_V1" readOnly />
                    <input type="submit" value="Probar contra test" />
                </form>
            </div>
        </div>
    ) : null;
}