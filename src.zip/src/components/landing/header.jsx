"use client";
import React, { useEffect, useState } from "react";
import Image from "next/image";
import MenuVertical from "@/components/ui/MenuHeader";
import UserAuth from "@/components/ui/UserAuthModal";
import Link from "next/link";
import { useSession } from 'next-auth/react';
import { ShoppingCart, Search } from 'lucide-react';
import { usePathname } from 'next/navigation';
import { useCart } from '@/contexts/CartContext.jsx';
import { InstagramIcon } from "lucide-react";
export default function Page() {
    // Get cart item count directly from localStorage
    const [cartItemsCount, setCartItemsCount] = useState(0);
    const [whatsappNumber, setWhatsappNumber] = useState("");
    const [Instagram, setInstagram] = useState("");
    useEffect(() => {
        function getCartCount() {
            try {
                const cartRaw = typeof window !== 'undefined' ? localStorage.getItem('cart') : null;
                if (!cartRaw) return 0;
                const cart = JSON.parse(cartRaw);
                if (!cart.items || !Array.isArray(cart.items)) return 0;
                return cart.items.reduce((total, item) => {
                    const qty = typeof item.quantity === 'number' && !isNaN(item.quantity) ? item.quantity : 1;
                    return total + qty;
                }, 0);
            } catch (e) {
                return 0;
            }
        }
        // Poll every 100ms for cart changes
        const interval = setInterval(() => {
            setCartItemsCount(getCartCount());
        }, 100);
        // Set initial value immediately
        setCartItemsCount(getCartCount());
        return () => clearInterval(interval);
    }, []);
    // Fetch WhatsApp number from parameters API
    useEffect(() => {
        async function fetchWhatsapp() {
            try {
                const res = await fetch('/api/shop-parameters');
                if (!res.ok) return;
                const params = await res.json();
                const whatsappParam = params.find(p => p.key === 'whatsapp');
                const instagramParam = params.find(p => p.key === 'instagarm');
                if (whatsappParam && whatsappParam.value) {
                    setWhatsappNumber(whatsappParam.value);
                }
                if (instagramParam && instagramParam.value) {
                    setInstagram(instagramParam.value);
                }
            } catch (e) { }
        }
        fetchWhatsapp();
    }, []);
    // Helper to dispatch cartUpdated event when cart is changed in this tab
    // You should call this after updating cart in localStorage elsewhere in your app:
    // window.dispatchEvent(new Event('cartUpdated'));
    const pathname = usePathname();
    // Locale switcher component (only for localized routes)
    const locales = [
        { code: 'ca', label: 'CA' },
        { code: 'es', label: 'ES' }
    ];
    // Only show switcher if route is localized
    const currentLocale = /^\/(ca|es)(\/|$)/.test(pathname) ? pathname.split('/')[1] : null;
    return (
        <div className="fixed top-0 z-40 w-full bg-white shadow-md px-2 md:px-5 py-2 ">
            <div className="flex flex-col justify-center w-full">
                <div className="w-full flex flex-row justify-between items-center">
                    {/* Hamburger menu */}
                    <div className="flex flex-row justify-start items-center px-0 md:px-4 py-2 w-[90px] md:w-[300px]">
                        <MenuVertical />
                        <Link
                            target="_blank"
                            href={Instagram ? Instagram : "https://www.instagram.com/subirananadons/"}>
                            <InstagramIcon className="hidden ml-5 mr-4 md:block w-6 h-6 text-gray-700 hover:text-[#36A9E1] cursor-pointer" />
                        </Link>
                        <Link
                            className="hidden md:block  cursor-pointer"
                            href={whatsappNumber ? "https://wa.me/" + whatsappNumber : "https://wa.me/34691357211"}
                            target="_blank"
                            rel="noopener noreferrer"
                        >
                            <svg className="text-gray-700 hover:text-[#36A9E1]" width="34px" height="34px" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                <path d="M17.6 6.31999C16.8669 5.58141 15.9943 4.99596 15.033 4.59767C14.0716 4.19938 13.0406 3.99622 12 3.99999C10.6089 4.00135 9.24248 4.36819 8.03771 5.06377C6.83294 5.75935 5.83208 6.75926 5.13534 7.96335C4.4386 9.16745 4.07046 10.5335 4.06776 11.9246C4.06507 13.3158 4.42793 14.6832 5.12 15.89L4 20L8.2 18.9C9.35975 19.5452 10.6629 19.8891 11.99 19.9C14.0997 19.9001 16.124 19.0668 17.6222 17.5816C19.1205 16.0965 19.9715 14.0796 19.99 11.97C19.983 10.9173 19.7682 9.87634 19.3581 8.9068C18.948 7.93725 18.3505 7.05819 17.6 6.31999ZM12 18.53C10.8177 18.5308 9.65701 18.213 8.64 17.61L8.4 17.46L5.91 18.12L6.57 15.69L6.41 15.44C5.55925 14.0667 5.24174 12.429 5.51762 10.8372C5.7935 9.24545 6.64361 7.81015 7.9069 6.80322C9.1702 5.79628 10.7589 5.28765 12.3721 5.37368C13.9853 5.4597 15.511 6.13441 16.66 7.26999C17.916 8.49818 18.635 10.1735 18.66 11.93C18.6442 13.6859 17.9355 15.3645 16.6882 16.6006C15.441 17.8366 13.756 18.5301 12 18.53ZM15.61 13.59C15.41 13.49 14.44 13.01 14.26 12.95C14.08 12.89 13.94 12.85 13.81 13.05C13.6144 13.3181 13.404 13.5751 13.18 13.82C13.07 13.96 12.95 13.97 12.75 13.82C11.6097 13.3694 10.6597 12.5394 10.06 11.47C9.85 11.12 10.26 11.14 10.64 10.39C10.6681 10.3359 10.6827 10.2759 10.6827 10.215C10.6827 10.1541 10.6681 10.0941 10.64 10.04C10.64 9.93999 10.19 8.95999 10.03 8.56999C9.87 8.17999 9.71 8.23999 9.58 8.22999H9.19C9.08895 8.23154 8.9894 8.25465 8.898 8.29776C8.8066 8.34087 8.72546 8.403 8.66 8.47999C8.43562 8.69817 8.26061 8.96191 8.14676 9.25343C8.03291 9.54495 7.98287 9.85749 8 10.17C8.0627 10.9181 8.34443 11.6311 8.81 12.22C9.6622 13.4958 10.8301 14.5293 12.2 15.22C12.9185 15.6394 13.7535 15.8148 14.58 15.72C14.8552 15.6654 15.1159 15.5535 15.345 15.3915C15.5742 15.2296 15.7667 15.0212 15.91 14.78C16.0428 14.4856 16.0846 14.1583 16.03 13.84C15.94 13.74 15.81 13.69 15.61 13.59Z" />
                            </svg>
                        </Link>
                        {/* <Link href="#" className="hidden md:block text-gray-700 font-semibold text-sm ml-2 hover:text-[#36A9E1] cursor-pointer">Tel: 938 751 567</Link> */}
                    </div>
                    <Link href="/" className="flex justify-center items-center w-[120px] md:w-[300px]">
                        <img
                            src="/assets/logo-header.svg"
                            alt="logo"
                            width={120}
                            height={60}
                            className="md:w-[250px] md:h-[70px] w-[120px] h-[40px] object-contain"
                        />
                    </Link>
                    <div className="w-[90px] md:w-[300px] flex justify-end space-x-2 md:space-x-4 text-gray-700">
                        {/* Locale Switcher: only show on localized routes */}
                        <div className="hidden sm:flex items-center space-x-2">
                            {currentLocale && (
                                <div className="flex items-center space-x-1">
                                    {locales.map(locale => (
                                        <a
                                            key={locale.code}
                                            href={pathname.replace(/^\/(ca|es)/, `/${locale.code}`)}
                                            className={`px-1 py-1 rounded text-[15px] mt-2 font-semibold transition-colors ${currentLocale === locale.code ? ' text-[#36A9E1]' : 'bg-white text-gray-500 border-gray-300 hover:bg-gray-100'}`}
                                            aria-current={currentLocale === locale.code ? 'page' : undefined}
                                        >
                                            {locale.label}
                                        </a>
                                    ))}
                                </div>
                            )}
                            <Link href="/search" className="p-2 ml-6 flex justify-center items-center">
                                <Search className="w-5 h-5 md:w-6 md:h-6 text-gray-700 hover:text-[#3f93ba]" />
                            </Link>
                        </div>
                        {/* Locale Switcher */}
                        <Link href="/cart" className="p-2 text-sm text-gray-700 relative">
                            <ShoppingCart className="w-5 h-5 md:w-6 md:h-6 text-gray-700 hover:text-[#3f93ba]" />
                            <span
                                className={
                                    `absolute top-1 -right-1 z-30 bg-[#36A9E1] text-white text-[10px] font-bold rounded-full w-4 h-4 flex items-center justify-center border border-white shadow
                                    ${cartItemsCount > 0 ? "animate-bounce" : ""}`
                                }
                            >
                                {cartItemsCount}
                            </span>
                        </Link>
                        <UserAuth title="" className="text-gray-700 hover:text-[#3f93ba]" />
                    </div>
                </div>
            </div>
        </div>
    );
}