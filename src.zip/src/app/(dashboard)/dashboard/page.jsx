import { redirect } from 'next/navigation';
export default function DashboardRedirect() {
    redirect('/dashboard/listas');
    return null;
}
