'use client';

import { useState, useEffect } from 'react';
import { FiX, FiSave } from 'react-icons/fi';

export default function OrderEditModal({ isOpen, onClose, onSave, order, isLoading }) {
    // Locale detection (default to 'ca')
    let locale = 'ca';
    if (typeof window !== 'undefined' && window.navigator) {
        const lang = window.navigator.language || window.navigator.userLanguage;
        if (lang && lang.toLowerCase().startsWith('es')) locale = 'es';
    }

    // Translations
    const translations = {
        ca: {
            editOrder: 'Editar Comanda',
            status: 'Estat',
            trackingNumber: 'Número de seguiment',
            trackingPlaceholder: 'Número de seguiment (opcional)',
            notes: 'Notes',
            notesPlaceholder: 'Notes addicionals sobre la comanda',
            cancel: 'Cancel·lar',
            save: 'Desar canvis',
            saving: 'Desant...',
            customer: 'Client',
            id: 'ID',
            statusOptions: {
                acceptado: 'Acceptat',
                procesando: 'Processant',
                enviado: 'Enviat',
                completo: 'Complet',
                cancelado: 'Cancel·lat',
            },
        },
        es: {
            editOrder: 'Editar Pedido',
            status: 'Estado',
            trackingNumber: 'Número de seguimiento',
            trackingPlaceholder: 'Número de seguimiento (opcional)',
            notes: 'Notas',
            notesPlaceholder: 'Notas adicionales sobre el pedido',
            cancel: 'Cancelar',
            save: 'Guardar cambios',
            saving: 'Guardando...',
            customer: 'Cliente',
            id: 'ID',
            statusOptions: {
                acceptado: 'Aceptado',
                procesando: 'Procesando',
                enviado: 'Enviado',
                completo: 'Completo',
                cancelado: 'Cancelado',
            },
        }
    };
    const t = translations[locale];
    const [formData, setFormData] = useState({
        status: '',
        trackingNumber: '',
        notes: ''
    });    // Initialize form data when order changes
    useEffect(() => {
        if (order) {
            // Map display status to DB status (identity for new statuses)
            setFormData({
                status: order.status || 'procesando',
                trackingNumber: order.trackingNumber || '',
                notes: order.notes || ''
            });
        }
    }, [order]);

    if (!isOpen || !order) return null;

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        onSave(order.id, formData);
    };

    return (
        <div className="fixed inset-0 bg-[#00000050] bg-opacity-50 z-50 flex justify-center items-center p-4">
            <div className="bg-white rounded-lg shadow-lg max-w-xl w-full">
                <div className="flex justify-between items-center border-b border-gray-200 p-4">
                    <h3 className="text-xl font-semibold">
                        {t.editOrder}: {order.reference}
                    </h3>
                    <button
                        onClick={onClose}
                        className="text-gray-500 hover:text-gray-700"
                        disabled={isLoading}
                    >
                        <FiX size={24} />
                    </button>
                </div>

                <form onSubmit={handleSubmit} className="p-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                                {t.status}
                            </label>
                            <select
                                name="status"
                                value={formData.status}
                                onChange={handleChange}
                                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-[#00B0C8] focus:border-[#00B0C8]"
                                disabled={isLoading}
                                required
                            >
                                <option value="acceptado">{t.statusOptions.acceptado}</option>
                                <option value="procesando">{t.statusOptions.procesando}</option>
                                <option value="enviado">{t.statusOptions.enviado}</option>
                                <option value="completo">{t.statusOptions.completo}</option>
                                <option value="cancelado">{t.statusOptions.cancelado}</option>
                            </select>
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                                {t.trackingNumber}
                            </label>
                            <input
                                type="text"
                                name="trackingNumber"
                                value={formData.trackingNumber}
                                onChange={handleChange}
                                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-[#00B0C8] focus:border-[#00B0C8]"
                                placeholder={t.trackingPlaceholder}
                                disabled={isLoading}
                            />
                        </div>
                    </div>

                    <div className="mt-4">
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                            {t.notes}
                        </label>
                        <textarea
                            name="notes"
                            value={formData.notes}
                            onChange={handleChange}
                            rows="3"
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-[#00B0C8] focus:border-[#00B0C8]"
                            placeholder={t.notesPlaceholder}
                            disabled={isLoading}
                        />
                    </div>

                    <div className="flex justify-between items-center mt-6 pt-4  ">
                        <div className="flex flex-col text-sm text-gray-500">
                            {/* <p>{t.id}: {order.id}</p> */}
                            <p>{t.customer}: {order.customer}</p>
                        </div>
                        <div className="flex space-x-3">
                            <button
                                type="button"
                                onClick={onClose}
                                className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#00B0C8]"
                                disabled={isLoading}
                            >
                                {t.cancel}
                            </button>
                            <button
                                type="submit"
                                className="px-4 py-2 border border-transparent rounded-md text-sm font-medium text-white bg-[#00B0C8] hover:bg-[#008da0] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#00B0C8] flex items-center"
                                disabled={isLoading}
                            >
                                <FiSave size={20} className="mr-2" />
                                {isLoading ? t.saving : t.save}
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    );
}