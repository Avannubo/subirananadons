'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import ShopLayout from "@/components/Layouts/shop-layout";
import Image from "next/image";
import { motion } from 'framer-motion';
import { toast } from 'react-hot-toast';
import Link from 'next/link';

import { useTranslations } from 'next-intl';

export default function BirthListsPage() {
    const [searchTerm, setSearchTerm] = useState('');
    const [bannerImage, setBannerImage] = useState(null);
    const router = useRouter();
    const t = useTranslations('BirthListsPage');

    useEffect(() => {
        const fetchBanner = async () => {
            try {
                const res = await fetch('/api/portimg/active');
                if (!res.ok) throw new Error('Failed to fetch banner');
                const data = await res.json();
                if (data && (data.image || data.imageUrl)) {
                    setBannerImage(data.image || data.imageUrl);
                }
            } catch (err) {
                console.error('Error fetching banner:', err);
            }
        };
        fetchBanner();
    }, []);

    const handleSearch = (e) => {
        e.preventDefault();
        if (!searchTerm) {
            toast.error(t('searchErrorEmpty'));
            return;
        }

        try {
            // Extract the ID from the URL
            let id;
            if (searchTerm.includes('/listas-de-nacimiento/')) {
                // Extract ID from full URL
                const matches = searchTerm.match(/\/listas-de-nacimiento\/([^/?]+)/);
                id = matches ? matches[1] : null;
            } else {
                // Treat the input as a direct ID
                id = searchTerm.trim();
            }

            if (!id) {
                toast.error(t('searchErrorInvalid'));
                return;
            }

            // Navigate to the birth list page
            router.push(`/listas-de-nacimiento/${id}`);
        } catch (error) {
            toast.error(t('searchErrorInvalid'));
        }
    };

    return (
        <ShopLayout>
            {bannerImage ? (
                <div className="relative w-full mt-10 h-[30vw] min-h-[120px] max-h-[180px] sm:h-[40vh] flex flex-col justify-center items-center rounded-b-2xl overflow-hidden shadow-md">
                    <img
                        src={bannerImage}
                        alt={t('bannerAlt')}
                        fill
                        className="object-cover"
                        priority
                    />
                    {/* Overlay for contrast */}
                    <div className="absolute inset-0 bg-white/70 z-10 pointer-events-none" />
                    <div className="absolute inset-0 flex items-center justify-center z-20">
                        <h1 className="text-xl sm:text-2xl md:text-4xl font-bold text-gray-800 shadow-amber-50 mt-8 lg:mt-20 drop-shadow-lg">{t('title')}</h1>
                    </div>
                </div>
            ) : (
                <div className="w-full mt-10 h-[30vw] min-h-[120px] max-h-[180px] sm:h-[40vh] flex flex-col justify-center items-center rounded-b-2xl bg-white">
                    <h1 className="text-xl sm:text-2xl md:text-4xl font-bold text-gray-800 mt-8 lg:mt-20">{t('title')}</h1>
                </div>
            )}
            {/* Search bar below the banner */}
            <div className="w-full flex flex-col items-center m-2  p-2 relative">
                <form onSubmit={handleSearch} className="w-full max-w-2xl mx-auto flex flex-col items-center">
                    <div className="w-full flex items-center bg-white bg-opacity-90 rounded-full shadow-md px-4 py-3 mb-2 border border-gray-200">
                        <input
                            type="text"
                            placeholder={t('searchPlaceholder')}
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="flex-1 bg-transparent border-none outline-none text-lg placeholder-gray-400 px-2"
                        />
                        <button
                            type="submit"
                            className="ml-2 text-gray-500 hover:text-[#00B0C8] focus:outline-none"
                        >
                            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                            </svg>
                        </button>
                    </div>
                    <p className="text-gray-700 text-sm text-center drop-shadow-sm">
                        {t('searchHelp')}
                    </p>
                </form>
            </div>
            <div className="container mx-auto p-4">
                <div className="flex flex-col md:flex-row gap-6 mb-12">
                    <motion.div
                        className="flex-1 bg-gradient-to-r from-[#00B0C8] to-[#0090a8] rounded-lg p-8 mb-6 md:mb-12 text-white"
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.5, duration: 0.5 }}
                    >
                        <div className="flex flex-col items-start justify-start space-y-4">
                            <div>
                                <h2 className="text-2xl font-bold mb-2">{t('expectingTitle')}</h2>
                                <p className="text-white/90">{t('expectingDesc')}</p>
                            </div>
                            <button
                                onClick={() => router.push('/dashboard/listas')}
                                className="mt-4 md:mt-0 px-8 py-3 bg-white text-[#00B0C8] rounded-full font-medium hover:bg-gray-100 transition-colors"
                            >
                                {t('createListBtn')}
                            </button>
                        </div>
                    </motion.div>
                    <motion.div
                        className="flex-1 bg-gradient-to-r from-[#00B0C8] to-[#0090a8] rounded-lg p-8 mb-6 md:mb-12 text-white"
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.5, duration: 0.5 }}
                    >
                        <div className="flex flex-col items-start justify-start space-y-4">
                            <div>
                                <h2 className="text-2xl font-bold mb-2">{t('recommendTitle')}</h2>
                                <p className="text-white/90">{t('recommendDesc')}</p>
                            </div>
                            <Link
                                href="/recomendations"
                                className="mt-4 md:mt-0 px-8 py-3 bg-white text-[#00B0C8] rounded-full font-medium hover:bg-gray-100 transition-colors"
                            >
                                {t('recommendBtn')}
                            </Link>
                        </div>
                    </motion.div>
                </div>
                {/* How It Works Section */}
                <motion.div
                    className="mt-8 md:mt-16 py-8 md:py-12 bg-gray-50 rounded-lg"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.6 }}
                >
                    <div className="container mx-auto px-2 md:px-4">
                        <h2 className="text-2xl font-bold text-center mb-8 md:mb-12">{t('howWorksTitle')}</h2>
                        <div className="flex flex-col md:flex-row md:space-x-4 space-y-8 md:space-y-0 overflow-x-auto">
                            <div className="flex-1 min-w-[220px] text-center">
                                <div className="flex items-center justify-center w-16 h-16 mx-auto mb-4 rounded-full bg-[#00B0C8] text-white">
                                    <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                                    </svg>
                                </div>
                                <h3 className="text-lg font-semibold mb-2">{t('howWorksStep1Title')}</h3>
                                <p className="text-gray-600">{t('howWorksStep1Desc')}</p>
                            </div>
                            <div className="flex-1 min-w-[220px] text-center">
                                <div className="flex items-center justify-center w-16 h-16 mx-auto mb-4 rounded-full bg-[#00B0C8] text-white">
                                    <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                                    </svg>
                                </div>
                                <h3 className="text-lg font-semibold mb-2">{t('howWorksStep2Title')}</h3>
                                <p className="text-gray-600">{t('howWorksStep2Desc')}</p>
                            </div>
                            <div className="flex-1 min-w-[220px] text-center">
                                <div className="flex items-center justify-center w-16 h-16 mx-auto mb-4 rounded-full bg-[#00B0C8] text-white">
                                    <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
                                    </svg>
                                </div>
                                <h3 className="text-lg font-semibold mb-2">{t('howWorksStep3Title')}</h3>
                                <p className="text-gray-600">{t('howWorksStep3Desc')}</p>
                            </div>
                            <div className="flex-1 min-w-[220px] text-center">
                                <div className="flex items-center justify-center w-16 h-16 mx-auto mb-4 rounded-full bg-[#00B0C8] text-white">
                                    <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M20 7l-8 4-8-4V5l8 4 8-4v2zM4 13.8V7.2l8 4 8-4v6.6" />
                                    </svg>
                                </div>
                                <h3 className="text-lg font-semibold mb-2">{t('howWorksStep4Title')}</h3>
                                <p className="text-gray-600">{t('howWorksStep4Desc')}</p>
                            </div>
                        </div>
                    </div>
                </motion.div>
            </div>
        </ShopLayout>
    );
}